/************************************************************************/
/*																		*/
/*	Cerebot_Plus.h --	Declarations for Cerebot Plus Board Devices		*/
/*																		*/
/************************************************************************/
/*	Author:		Gene Apperson											*/
/*	Copyright 2009, Digilent Inc.										*/
/************************************************************************/
/*  File Description:													*/
/*																		*/
/*	Declarations for symbols defining on-board Cerebot devices.			*/
/*																		*/
/*	The declarations in this header assume that the WinAVR standard		*/
/*	i/o file has been included. (avr/io.h)								*/
/*																		*/
/*	The following naming conventions are used:							*/
/*		prtXXXX		- output port register number (PORTA, PORTB, etc)	*/
/*		pinXXXX		- input pin register number (PINA, PINB, etc)		*/
/*		ddrXXXX		- data direction register (DDRA, DDRB, etc)			*/
/*		bnXXX		- bit number within a register						*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	01/05/2005(GeneA): created for Cerebot								*/
/*	04/25/2009(GeneA): Revised for Cerebot Plus							*/
/*																		*/
/************************************************************************/

#if !defined(_CEREBOT_PLUS_INC)
#define	_CEREBOT_PLUS_INC

/* ------------------------------------------------------------ */
/*				Declarations for On-Board LEDs					*/
/* ------------------------------------------------------------ */
/* NOTE: The on-board LEDs are shared with the pins on interface
**	connector JG. To drive the LEDs, the appropriate PORTE bits
**	are set as outputs. A 1 on the output port pin turns the LED
**	on, a 0 turns it off. The LEDs consume about 1.6ma of current,
**	which should not interfere with most uses of these pins to
**	drive logic connected to JG.
*/
#define	prtLed0	PORTE		// output port for LED0
#define	prtLed1	PORTE		// output port for LED1
#define	prtLed2	PORTE		// output port for LED2
#define	prtLed3	PORTE		// output port for LED3

#define	ddrLed0	DDRE
#define	ddrLed1	DDRE
#define	ddrLed2	DDRE
#define	ddrLed3	DDRE

#define	bnLed0	4
#define	bnLed1	5
#define	bnLed2	6
#define	bnLed3	7

/* External memory interface.
** This defines the pins used to drive the chip enable (CE) pin
** and the high order address pin (A15) on the extrnal memory
** device. It is necessary to enable the external memory controller
** in the ATmega2560 device to use the external memory.
** the CE and A15 pins are pulled down on the board, so it isn't
** necessary to drive these pins at all to access the lower bank
** in the external memory device.
*/
#define prtXmCs		PORTG
#define	prtXmBsel	PORTG

#define	pinXmCs		PING
#define	pinXmBsel	PING

#define	ddrXmCs		DDRG
#define	ddrXmBsel	DDRG

#define	bnXmCs		5
#define	bnXmBsel	3

/* User input jumper
** The user input jumper can be read by making this pin an input.
** The pin will read 0 when the jumper is in the '0' position and 1
** when the jumper is in the '1' position.
*/
#define	prtJP5		PORTG
#define	pinJP5		PING
#define	ddrJP5		DDRG
#define	bnJP5		4

/* ------------------------------------------------------------ */
/*			Declarations for Pmod Connector Pins				*/
/* ------------------------------------------------------------ */

/* The following symbols define the interface for connector JA
*/
#define	prtJA1	PORTA
#define	prtJA2	PORTA
#define	prtJA3	PORTA
#define	prtJA4	PORTA
#define	prtJA7	PORTA
#define	prtJA8	PORTA
#define	prtJA9	PORTA
#define	prtJA10	PORTA

#define pinJA1	PINA
#define	pinJA2	PINA
#define pinJA3	PINA
#define pinJA4	PINA
#define pinJA7	PINA
#define	pinJA8	PINA
#define pinJA9	PINA
#define pinJA10	PINA

#define	ddrJA1	DDRA
#define	ddrJA2	DDRA
#define	ddrJA3	DDRA
#define	ddrJA4	DDRA
#define	ddrJA7	DDRA
#define	ddrJA8	DDRA
#define	ddrJA9	DDRA
#define	ddrJA10	DDRA

#define	bnJA1	0
#define	bnJA2	1
#define	bnJA3	2
#define	bnJA4	3
#define	bnJA7	4
#define	bnJA8	5
#define	bnJA9	6
#define	bnJA10	7

/* The following symbols define the interface for connector JB
*/
#define	prtJB1	PORTC
#define	prtJB2	PORTC
#define	prtJB3	PORTC
#define	prtJB4	PORTC
#define	prtJB7	PORTC
#define	prtJB8	PORTC
#define	prtJB9	PORTC
#define	prtJB10	PORTC

#define pinJB1	PINC
#define	pinJB2	PINC
#define pinJB3	PINC
#define pinJB4	PINC
#define pinJB7	PINC
#define	pinJB8	PINC
#define pinJB9	PINC
#define pinJB10	PINC

#define	ddrJB1	DDRC
#define	ddrJB2	DDRC
#define	ddrJB3	DDRC
#define	ddrJB4	DDRC
#define	ddrJB7	DDRC
#define	ddrJB8	DDRC
#define	ddrJB9	DDRC
#define	ddrJB10	DDRC

#define	bnJB1	0
#define	bnJB2	1
#define	bnJB3	2
#define	bnJB4	3
#define	bnJB7	4
#define	bnJB8	5
#define	bnJB9	6
#define	bnJB10	7

/* The following symbols define the interface for connector JC
*/
#define	prtJC1	PORTE
#define	prtJC2	PORTE
#define	prtJC3	PORTE
#define	prtJC4	PORTE
#define	prtJC7	PORTG
#define	prtJC8	PORTG
#define	prtJC9	PORTG
#define	prtJC10	PORTG

#define	pinJC1	PINE
#define	pinJC2	PINE
#define	pinJC3	PINE
#define	pinJC4	PINE
#define	pinJC7	PING
#define	pinJC8	PING
#define	pinJC9	PING
#define	pinJC10 PING

#define	ddrJC1	DDRE
#define	ddrJC2	DDRE
#define	ddrJC3	DDRE
#define	ddrJC4	DDRE
#define	ddrJC7	DDRG
#define	ddrJC8	DDRG
#define	ddrJC9	DDRG
#define	ddrJC0	DDRG

#define	bnJC1	2
#define	bnJC2	3
#define	bnJC3	0
#define	bnJC4	1
#define	bnJC7	0
#define	bnJC8	1
#define	bnJC9	2
#define	bnJC10	3

/* The following symbols define the interface for connector JD
*/
#define	prtJD1	PORTB
#define	prtJD2	PORTB
#define	prtJD3	PORTB
#define	prtJD4	PORTB
#define	prtJD7	PORTD
#define	prtJD8	PORTD
#define	prtJD9	PORTD
#define	prtJD10	PORTD

#define	pinJD1	PINB
#define	pinJD2	PINB
#define	pinJD3	PINB
#define	pinJD4	PINB
#define	pinJD7	PIND
#define	pinJD8	PIND
#define	pinJD9	PIND
#define	pinJD10	PIND

#define	ddrJD1	DDRB
#define	ddrJD2	DDRB
#define	ddrJD3	DDRB
#define	ddrJD4	DDRB
#define	ddrJD7	DDRD
#define	ddrJD8	DDRD
#define	ddrJD9	DDRD
#define	ddrJD10	DDRD

#define	bnJD1	0
#define	bnJD2	2
#define	bnJD3	3
#define	bnJD4	1
#define	bnJD7	0
#define	bnJD8	1
#define	bnJD9	2
#define	bnJD10	3

/* The following symbols define the interface for connector JE
*/
#define	prtJE1	PORTD
#define	prtJE2	PORTB
#define	prtJE3	PORTD
#define	prtJE4	PORTB
#define	prtJE7	PORTD
#define	prtJE8	PORTB
#define	prtJE9	PORTD
#define	prtJE10	PORTB

#define	pinJE1	PIND
#define	pinJE2	PINB
#define pinJE3	PIND
#define	pinJE4	PINB
#define	pinJE7	PIND
#define	pinJE8	PINB
#define pinJE9	PIND
#define	pinJE10	PINB

#define	ddrJE1	DDRD
#define	ddrJE2	DDRB
#define	ddrJE3	DDRD
#define	ddrJE4	DDRB
#define	ddrJE7	DDRD
#define	ddrJE8	DDRB
#define	ddrJE9	DDRD
#define	ddrJE10	DDRB

#define	bnJE1	6
#define	bnJE2	5
#define	bnJE3	4
#define	bnJE4	6
#define	bnJE7	7
#define	bnJE8	4
#define	bnJE9	5
#define	bnJE10	7

/* The following symbols define the interface for connector JF
*/
#define	prtJF1	PORTL
#define	prtJF2	PORTL
#define	prtJF3	PORTL
#define	prtJF4	PORTL
#define	prtJF7	PORTL
#define	prtJF8	PORTL
#define	prtJF9	PORTL
#define	prtJF10	PORTL

#define	pinJF1	PINL
#define	pinJF2	PINL
#define	pinJF3	PINL
#define	pinJF4	PINL
#define	pinJF7	PINL
#define	pinJF8	PINL
#define	pinJF9	PINL
#define	pinJF10	PINL

#define	ddrJF1	DDRL
#define	ddrJF2	DDRL
#define	ddrJF3	DDRL
#define	ddrJF4	DDRL
#define	ddrJF7	DDRL
#define	ddrJF8	DDRL
#define	ddrJF9	DDRL
#define	ddrJF10	DDRL

#define	bnJF1	2
#define	bnJF2	3
#define	bnJF3	1
#define	bnJF4	4
#define	bnJF7	6
#define	bnJF8	5
#define	bnJF9	0
#define	bnJF10	7

/* The following symbols define the interface for connector JG
*/
#define	prtJG1	PORTE
#define	prtJG2	PORTE
#define	prtJG3	PORTE
#define	prtJG4	PORTE

#define	pinJG1	PINE
#define	pinJG2	PINE
#define	pinJG3	PINE
#define	pinJG4	PINE

#define	ddrJG1	DDRE
#define	ddrJG2	DDRE
#define	ddrJG3	DDRE
#define	ddrJG4	DDRE

#define	bnJG1	6
#define	bnJG2	4
#define	bnJG3	7
#define	bnJG4	5

/* The following symbols define the interface for connector JH
*/
#define	prtJH1	PORTH
#define	prtJH2	PORTH
#define	prtJH3	PORTH
#define	prtJH4	PORTH
#define	prtJH7	PORTH
#define	prtJH8	PORTH
#define	prtJH9	PORTH
#define	prtJH10	PORTH

#define pinJH1	PINH
#define	pinJH2	PINH
#define pinJH3	PINH
#define pinJH4	PINH
#define pinJH7	PINH
#define	pinJH8	PINH
#define pinJH9	PINH
#define pinJH10	PINH

#define	ddrJH1	DDRH
#define	ddrJH2	DDRH
#define	ddrJH3	DDRH
#define	ddrJH4	DDRH
#define	ddrJH7	DDRH
#define	ddrJH8	DDRH
#define	ddrJH9	DDRH
#define	ddrJH10	DDRH

#define	bnJH1	2
#define	bnJH2	3
#define	bnJH3	0
#define	bnJH4	1
#define	bnJH7	7
#define	bnJH8	4
#define	bnJH9	6
#define	bnJH10	5

/* The following symbols define the interface for connector JJ
*/
#define	prtJJ1	PORTF
#define	prtJJ2	PORTF
#define	prtJJ3	PORTF
#define	prtJJ4	PORTF
#define	prtJJ7	PORTF
#define	prtJJ8	PORTF
#define	prtJJ9	PORTF
#define	prtJJ10	PORTF

#define pinJJ1	PINF
#define	pinJJ2	PINF
#define pinJJ3	PINF
#define pinJJ4	PINF
#define pinJJ7	PINF
#define	pinJJ8	PINF
#define pinJJ9	PINF
#define pinJJ10	PINF

#define	ddrJJ1	DDRF
#define	ddrJJ2	DDRF
#define	ddrJJ3	DDRF
#define	ddrJJ4	DDRF
#define	ddrJJ7	DDRF
#define	ddrJJ8	DDRF
#define	ddrJJ9	DDRF
#define	ddrJJ10	DDRF

#define	bnJJ1	0
#define	bnJJ2	1
#define	bnJJ3	2
#define	bnJJ4	3
#define	bnJJ7	4
#define	bnJJ8	5
#define	bnJJ9	6
#define	bnJJ10	7

/* The following symbols define the interface for connector JK
*/
#define	prtJK1	PORTK
#define	prtJK2	PORTK
#define	prtJK3	PORTK
#define	prtJK4	PORTK
#define	prtJK7	PORTK
#define	prtJK8	PORTK
#define	prtJK9	PORTK
#define	prtJK10	PORTK

#define pinJK1	PINK
#define	pinJK2	PINK
#define pinJK3	PINK
#define pinJK4	PINK
#define pinJK7	PINK
#define	pinJK8	PINK
#define pinJK9	PINK
#define pinJK10	PINK

#define	ddrJK1	DDRK
#define	ddrJK2	DDRK
#define	ddrJK3	DDRK
#define	ddrJK4	DDRK
#define	ddrJK7	DDRK
#define	ddrJK8	DDRK
#define	ddrJK9	DDRK
#define	ddrJK10	DDRK

#define	bnJK1	0
#define	bnJK2	1
#define	bnJK3	2
#define	bnJK4	3
#define	bnJK7	4
#define	bnJK8	5
#define	bnJK9	6
#define	bnJK10	7

/* The following symbols define the interface for connector JL
*/
#define	prtJL1	PORTJ
#define	prtJL2	PORTJ
#define	prtJL3	PORTJ
#define	prtJL4	PORTJ
#define	prtJL7	PORTJ
#define	prtJL8	PORTJ
#define	prtJL9	PORTJ
#define	prtJL10	PORTJ

#define pinJL1	PINJ
#define	pinJL2	PINJ
#define pinJL3	PINJ
#define pinJL4	PINJ
#define pinJL7	PINJ
#define	pinJL8	PINJ
#define pinJL9	PINJ
#define pinJL10	PINJ

#define	ddrJL1	DDRJ
#define	ddrJL2	DDRJ
#define	ddrJL3	DDRJ
#define	ddrJL4	DDRJ
#define	ddrJL7	DDRJ
#define	ddrJL8	DDRJ
#define	ddrJL9	DDRJ
#define	ddrJL10	DDRJ

#define	bnJL1	2
#define	bnJL2	3
#define	bnJL3	0
#define	bnJL4	1
#define	bnJL7	4
#define	bnJL8	5
#define	bnJL9	6
#define	bnJL10	7

/* ------------------------------------------------------------ */
/*			Servo Connector Definitions							*/
/* ------------------------------------------------------------ */

#define	prtServo1	PORTF
#define	prtServo2	PORTF
#define	prtServo3	PORTF
#define	prtServo4	PORTF
#define	prtServo5	PORTF
#define	prtServo6	PORTF
#define	prtServo7	PORTF
#define	prtServo8	PORTF

#define	pinServo1	PINF
#define	pinServo2	PINF
#define	pinServo3	PINF
#define	pinServo4	PINF
#define	pinServo5	PINF
#define	pinServo6	PINF
#define	pinServo7	PINF
#define	pinServo8	PINF

#define	ddrServo1	DDRF
#define	ddrServo2	DDRF
#define	ddrServo3	DDRF
#define	ddrServo4	DDRF
#define	ddrServo5	DDRF
#define	ddrServo6	DDRF
#define	ddrServo7	DDRF
#define	ddrServo8	DDRF

#define	bnServo1	0
#define	bnServo2	1
#define	bnServo3	2
#define	bnServo4	3
#define	bnServo5	4
#define	bnServo6	5
#define	bnServo7	6
#define	bnServo8	7

/* ------------------------------------------------------------ */

#endif

/************************************************************************/
