/************************************************************************/
/*																		*/
/*	cerebot.h	--	Declarations for Cerebot Devices					*/
/*																		*/
/************************************************************************/
/*	Author:		Gene Apperson											*/
/*	Copyright 2005, Digilent Inc.										*/
/************************************************************************/
/*  File Description:													*/
/*																		*/
/*	Declarations for symbols defining on-board Cerebot devices.			*/
/*																		*/
/*	The declarations in this header assume that the WinAVR standard		*/
/*	i/o file has been included. (avr/io.h)								*/
/*																		*/
/*	The following naming conventions are used:							*/
/*		prtXXXX		- output port register number (PORTA, PORTB, etc)	*/
/*		pinXXXX		- input pin register number (PINA, PINB, etc)		*/
/*		ddrXXXX		- data direction register (DDRA, DDRB, etc)			*/
/*		bnXXX		- bit number within a register						*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	01/05/2005(GeneA): created											*/
/*																		*/
/************************************************************************/

#if !defined(_CEREBOT_INC)
#define	_CEREBOT_INC

/* ------------------------------------------------------------ */
/*				Declarations for On-Board LEDs					*/
/* ------------------------------------------------------------ */
/* NOTE: The on-board LEDs are shared with the pins on interface
**	connector JC. To drive the LEDs, the appropriate PORTE bits
**	are set as outputs. A 1 on the output port pin turns the LED
**	on, a 0 turns it off. The LEDs consume about 1.6ma of current,
**	which should not interfere with most uses of these pins to
**	drive logic connected to JC.
*/

#define	prtLed0	PORTE		// output port for LED0
#define	prtLed1	PORTE		// output port for LED1
#define	prtLed2	PORTE		// output port for LED2
#define	prtLed3	PORTE		// output port for LED3

#define	ddrLed0	DDRE
#define	ddrLed1	DDRE
#define	ddrLed2	DDRE
#define	ddrLed3	DDRE

#define	bnLed0	4
#define	bnLed1	5
#define	bnLed2	6
#define	bnLed3	7

/* ------------------------------------------------------------ */
/*			Declarations for External RAM Interface				*/
/* ------------------------------------------------------------ */
/* Note: There is a pulldown resistor on the board so that the
**	external ram is enabled by default. To disable external ram,
**	set PORTG, bit 3, as an output with the value 1
**	(prtExtRamEn, ddrExtRamEn, bnExtRamEn)
**	There is 128K bytes of external RAM on the Cerebot. Since
**	the ATmega64 is only capable of addressing 64K of ram, the
**	128K is divided into two banks of 64k selected by a bank
**	select line driven by an i/o pin. The bank select line is 
**	pulled down by default. To select banks, set PORTG, bit 4 
**	as an output. Set this pin to 0 to select bank 0 and to 1 to 
**	select bank 1.
**	(prtBankSel, ddrBankSel, bnBankSel)
*/

#define	ExtRamBase	0x1100		//start address of external RAM
#define	prtBankSel	PORTG
#define	prtExtRamEn	PORTG

#define	ddrBankSel	DDRG
#define	ddrExtRamEn	DDRG

#define	bnBankSel	3
#define	bnExtRamEn	4			//set to 1 to disable ext ram

/* ------------------------------------------------------------ */
/*			Declarations for Interface Connector Pins			*/
/* ------------------------------------------------------------ */

/* The following symbols define the interface for connector JM
*/
#define	prtJM1	PORTB
#define	prtJM2	PORTB
#define	prtJM3	PORTB
#define	prtJM4	PORTB

#define	pinJM1	PINB
#define	pinJM2	PINB
#define pinJM3	PINB
#define	pinJM4	PINB

#define	ddrJM1	DDRB
#define	ddrJM2	DDRB
#define	ddrJM3	DDRB
#define	ddrJM4	DDRB

#define	bnJM1	0
#define	bnJM2	2
#define	bnJM3	3
#define	bnJM4	1

/* The following symbols define the interface for connector JA
*/
#define	prtJA1	PORTD
#define	prtJA2	PORTB
#define	prtJA3	PORTD
#define	prtJA4	PORTB

#define pinJA1	PIND
#define	pinJA2	PINB
#define pinJA3	PIND
#define pinJA4	PINB

#define	ddrJA1	DDRD
#define	ddrJA2	DDRB
#define	ddrJA3	DDRD
#define	ddrJA4	DDRB

#define	bnJA1	7
#define	bnJA2	4
#define	bnJA3	5
#define	bnJA4	7

/* The following symbols define the interface for connector JB
*/
#define	prtJB1	PORTD
#define	prtJB2	PORTB
#define	prtJB3	PORTD
#define	prtJB4	PORTB

#define	pinJB1	PIND
#define	pinJB2	PINB
#define	pinJB3	PIND
#define	pinJB4	PINB

#define	ddrJB1	DDRD
#define	ddrJB2	DDRB
#define	ddrJB3	DDRD
#define	ddrJB4	DDRB

#define	bnJB1	6
#define	bnJB2	5
#define	bnJB3	4
#define	bnJB4	6

/* The following symbols define the interface for connector JC
*/
#define	prtJC1	PORTE
#define	prtJC2	PORTE
#define	prtJC3	PORTE
#define	prtJC4	PORTE

#define	pinJC1	PINE
#define	pinJC2	PINE
#define	pinJC3	PINE
#define	pinJC4	PINE

#define	ddrJC1	DDRE
#define	ddrJC2	DDRE
#define	ddrJC3	DDRE
#define	ddrJC4	DDRE

#define	bnJC1	6
#define	bnJC2	4
#define	bnJC3	7
#define	bnJC4	5

/* The following symbols define the interface for connector JD
*/
#define	prtJD1	PORTE
#define	prtJD2	PORTE
#define	prtJD3	PORTE
#define	prtJD4	PORTE

#define	pinJD1	PINE
#define	pinJD2	PINE
#define	pinJD3	PINE
#define	pinJD4	PINE

#define	ddrJD1	DDRE
#define	ddrJD2	DDRE
#define	ddrJD3	DDRE
#define	ddrJD4	DDRE

#define	bnJD1	2
#define	bnJD2	3
#define	bnJD3	0
#define	bnJD4	1

/* The following symbols define the interface for connector JE
*/
#define	prtJE1	PORTD
#define	prtJE2	PORTD
#define	prtJE3	PORTD
#define	prtJE4	PORTD

#define	pinJE1	PIND
#define	pinJE2	PIND
#define pinJE3	PIND
#define	pinJE4	PIND

#define	ddrJE1	DDRD
#define	ddrJE2	DDRD
#define	ddrJE3	DDRD
#define	ddrJE4	DDRD

#define	bnJE1	0
#define	bnJE2	1
#define	bnJE3	2
#define	bnJE4	3

/* The following symbols define the interface for connector JF
*/
#define	prtJF1	PORTF
#define	prtJF2	PORTF
#define	prtJF3	PORTF
#define	prtJF4	PORTF

#define	pinJF1	PINF
#define	pinJF2	PINF
#define	pinJF3	PINF
#define	pinJF4	PINF

#define	ddrJF1	DDRF
#define	ddrJF2	DDRF
#define	ddrJF3	DDRF
#define	ddrJF4	DDRF

#define	bnJF1	0
#define	bnJF2	1
#define	bnJF3	2
#define	bnJF4	3

/* The following symbols define the interface for connector JG
** Note: These pins are shared with the JTAG interface and are only
**	available for user i/o if the JTAG interface has been disabled.
*/
#define	prtJG1	PORTF
#define	prtJG2	PORTF
#define	prtJG3	PORTF
#define	prtJG4	PORTF

#define	pinJG1	PINF
#define	pinJG2	PINF
#define	pinJG3	PINF
#define	pinJG4	PINF

#define	ddrJG1	DDRF
#define	ddrJG2	DDRF
#define	ddrJG3	DDRF
#define	ddrJG4	DDRF

#define	bnJG1	5
#define	bnJG2	7
#define	bnJG3	6
#define	bnJG4	4

/* ------------------------------------------------------------ */

#endif

/************************************************************************/
