/************************************************************************/
/*																		*/
/*	Cerebot_II.h --	Declarations for Cerebot II Board					*/
/*																		*/
/************************************************************************/
/*	Author:		Gene Apperson											*/
/*	Copyright 2005, 2007, 2009 Digilent Inc.							*/
/************************************************************************/
/*  File Description:													*/
/*																		*/
/*	Declarations for symbols defining on-board Cerebot devices.			*/
/*																		*/
/*	The declarations in this header assume that the WinAVR standard		*/
/*	i/o file has been included. (avr/io.h)								*/
/*																		*/
/*	The following naming conventions are used:							*/
/*		prtXXXX		- output port register number (PORTA, PORTB, etc)	*/
/*		pinXXXX		- input pin register number (PINA, PINB, etc)		*/
/*		ddrXXXX		- data direction register (DDRA, DDRB, etc)			*/
/*		bnXXX		- bit number within a register						*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	01/05/2005(GeneA): created for Cererbot								*/
/*	07/30/2007(GeneA): Revised for Cerebot II							*/
/*	04/25/2009(GeneA): Added declarations for JP5						*/
/*																		*/
/************************************************************************/

#if !defined(_CEREBOT_II_INC)
#define	_CEREBOT_II_INC

/* ------------------------------------------------------------ */
/*				Declarations for On-Board LEDs					*/
/* ------------------------------------------------------------ */
/* NOTE: The on-board LEDs are shared with the pins on interface
**	connector JC. To drive the LEDs, the appropriate PORTE bits
**	are set as outputs. A 1 on the output port pin turns the LED
**	on, a 0 turns it off. The LEDs consume about 1.9ma of current,
**	which should not interfere with most uses of these pins to
**	drive logic connected to JC.
*/
#define	prtLed0	PORTE		// output port for LED0
#define	prtLed1	PORTE		// output port for LED1
#define	prtLed2	PORTE		// output port for LED2
#define	prtLed3	PORTE		// output port for LED3

#define	ddrLed0	DDRE
#define	ddrLed1	DDRE
#define	ddrLed2	DDRE
#define	ddrLed3	DDRE

#define	bnLed0	4
#define	bnLed1	5
#define	bnLed2	6
#define	bnLed3	7

/* User input jumper
** The user input jumper can be read by making this pin an input.
** The pin will read 0 when the jumper is in the '0' position and 1
** when the jumper is in the '1' position.
*/
#define	prtJP5		PORTG
#define	pinJP5		PING
#define	ddrJP5		DDRG
#define	bnJP5		4

/* ------------------------------------------------------------ */
/*			Declarations for Interface Connector Pins			*/
/* ------------------------------------------------------------ */

/* The following symbols define the interface for connector JA
*/
#define	prtJA1	PORTA
#define	prtJA2	PORTA
#define	prtJA3	PORTA
#define	prtJA4	PORTA
#define	prtJA7	PORTA
#define	prtJA8	PORTA
#define	prtJA9	PORTA
#define	prtJA10	PORTA

#define pinJA1	PINA
#define	pinJA2	PINA
#define pinJA3	PINA
#define pinJA4	PINA
#define pinJA7	PINA
#define	pinJA8	PINA
#define pinJA9	PINA
#define pinJA10	PINA

#define	ddrJA1	DDRA
#define	ddrJA2	DDRA
#define	ddrJA3	DDRA
#define	ddrJA4	DDRA
#define	ddrJA7	DDRA
#define	ddrJA8	DDRA
#define	ddrJA9	DDRA
#define	ddrJA10	DDRA

#define	bnJA1	0
#define	bnJA2	1
#define	bnJA3	2
#define	bnJA4	3
#define	bnJA7	4
#define	bnJA8	5
#define	bnJA9	6
#define	bnJA10	7

/* The following symbols define the interface for connector JB
*/
#define	prtJB1	PORTC
#define	prtJB2	PORTC
#define	prtJB3	PORTC
#define	prtJB4	PORTC
#define	prtJB7	PORTC
#define	prtJB8	PORTC
#define	prtJB9	PORTC
#define	prtJB10	PORTC

#define pinJB1	PINC
#define	pinJB2	PINC
#define pinJB3	PINC
#define pinJB4	PINC
#define pinJB7	PINC
#define	pinJB8	PINC
#define pinJB9	PINC
#define pinJB10	PINC

#define	ddrJB1	DDRC
#define	ddrJB2	DDRC
#define	ddrJB3	DDRC
#define	ddrJB4	DDRC
#define	ddrJB7	DDRC
#define	ddrJB8	DDRC
#define	ddrJB9	DDRC
#define	ddrJB10	DDRC

#define	bnJB1	0
#define	bnJB2	1
#define	bnJB3	2
#define	bnJB4	3
#define	bnJB7	4
#define	bnJB8	5
#define	bnJB9	6
#define	bnJB10	7

/* The following symbols define the interface for connector JC
*/
#define	prtJC1	PORTE
#define	prtJC2	PORTE
#define	prtJC3	PORTE
#define	prtJC4	PORTE
#define	prtJC7	PORTG
#define	prtJC8	PORTG
#define	prtJC9	PORTG
#define	prtJC10	PORTG

#define	pinJC1	PINE
#define	pinJC2	PINE
#define	pinJC3	PINE
#define	pinJC4	PINE
#define	pinJC7	PING
#define	pinJC8	PING
#define	pinJC9	PING
#define	pinJC10 PING

#define	ddrJC1	DDRE
#define	ddrJC2	DDRE
#define	ddrJC3	DDRE
#define	ddrJC4	DDRE
#define	ddrJC7	DDRG
#define	ddrJC8	DDRG
#define	ddrJC9	DDRG
#define	ddrJC0	DDRG

#define	bnJC1	2
#define	bnJC2	3
#define	bnJC3	0
#define	bnJC4	1
#define	bnJC7	0
#define	bnJC8	1
#define	bnJC9	2
#define	bnJC10	3

/* The following symbols define the interface for connector JD
*/
#define	prtJD1	PORTB
#define	prtJD2	PORTB
#define	prtJD3	PORTB
#define	prtJD4	PORTB
#define	prtJD7	PORTD
#define	prtJD8	PORTD
#define	prtJD9	PORTD
#define	prtJD10	PORTD

#define	pinJD1	PINB
#define	pinJD2	PINB
#define	pinJD3	PINB
#define	pinJD4	PINB
#define	pinJD7	PIND
#define	pinJD8	PIND
#define	pinJD9	PIND
#define	pinJD10	PIND

#define	ddrJD1	DDRB
#define	ddrJD2	DDRB
#define	ddrJD3	DDRB
#define	ddrJD4	DDRB
#define	ddrJD7	DDRD
#define	ddrJD8	DDRD
#define	ddrJD9	DDRD
#define	ddrJD10	DDRD

#define	bnJD1	0
#define	bnJD2	2
#define	bnJD3	3
#define	bnJD4	1
#define	bnJD7	0
#define	bnJD8	1
#define	bnJD9	2
#define	bnJD10	3

/* The following symbols define the interface for connector JE
*/
#define	prtJE1	PORTD
#define	prtJE2	PORTB
#define	prtJE3	PORTD
#define	prtJE4	PORTB

#define	pinJE1	PIND
#define	pinJE2	PINB
#define pinJE3	PIND
#define	pinJE4	PINB

#define	ddrJE1	DDRD
#define	ddrJE2	DDRB
#define	ddrJE3	DDRD
#define	ddrJE4	DDRB

#define	bnJE1	6
#define	bnJE2	5
#define	bnJE3	4
#define	bnJE4	6

/* The following symbols define the interface for connector JF
*/
#define	prtJF1	PORTE
#define	prtJF2	PORTE
#define	prtJF3	PORTE
#define	prtJF4	PORTE

#define	pinJF1	PINE
#define	pinJF2	PINE
#define	pinJF3	PINE
#define	pinJF4	PINE

#define	ddrJF1	DDRE
#define	ddrJF2	DDRE
#define	ddrJF3	DDRE
#define	ddrJF4	DDRE

#define	bnJF1	6
#define	bnJF2	4
#define	bnJF3	7
#define	bnJF4	5

/* The following symbols define the interface for connector JG
*/
#define	prtJG1	PORTD
#define	prtJG2	PORTB
#define	prtJG3	PORTD
#define	prtJG4	PORTB

#define	pinJG1	PIND
#define	pinJG2	PINB
#define	pinJG3	PIND
#define	pinJG4	PINB

#define	ddrJG1	DDRD
#define	ddrJG2	DDRB
#define	ddrJG3	DDRD
#define	ddrJG4	DDRB

#define	bnJG1	7
#define	bnJG2	4
#define	bnJG3	5
#define	bnJG4	7

/* The following symbols define the interface for connector JH.
** NOTE: Pins 7-10 (port F bits 4-7) are shared with the JTAG interface
** and are only available for use as I/O pins when the JTAG interface
** is disabled.
** NOTE: These pins are also shared with the servo connectors.
*/
#define	prtJH1	PORTF
#define	prtJH2	PORTF
#define	prtJH3	PORTF
#define	prtJH4	PORTF
#define	prtJH7	PORTF
#define	prtJH8	PORTF
#define	prtJH9	PORTF
#define	prtJH10	PORTF

#define pinJH1	PINF
#define	pinJH2	PINF
#define pinJH3	PINF
#define pinJH4	PINF
#define pinJH7	PINF
#define	pinJH8	PINF
#define pinJH9	PINF
#define pinJH10	PINF

#define	ddrJH1	DDRF
#define	ddrJH2	DDRF
#define	ddrJH3	DDRF
#define	ddrJH4	DDRF
#define	ddrJH7	DDRF
#define	ddrJH8	DDRF
#define	ddrJH9	DDRF
#define	ddrJH10	DDRF

#define	bnJH1	0
#define	bnJH2	1
#define	bnJH3	2
#define	bnJH4	3
#define	bnJH7	4
#define	bnJH8	5
#define	bnJH9	6
#define	bnJH10	7

/* ------------------------------------------------------------ */
/*			Servo Connector Definitions							*/
/* ------------------------------------------------------------ */

#define	prtServo1	PORTF
#define	prtServo2	PORTF
#define	prtServo3	PORTF
#define	prtServo4	PORTF
#define	prtServo5	PORTF
#define	prtServo6	PORTF
#define	prtServo7	PORTF
#define	prtServo8	PORTF

#define	pinServo1	PINF
#define	pinServo2	PINF
#define	pinServo3	PINF
#define	pinServo4	PINF
#define	pinServo5	PINF
#define	pinServo6	PINF
#define	pinServo7	PINF
#define	pinServo8	PINF

#define	ddrServo1	DDRF
#define	ddrServo2	DDRF
#define	ddrServo3	DDRF
#define	ddrServo4	DDRF
#define	ddrServo5	DDRF
#define	ddrServo6	DDRF
#define	ddrServo7	DDRF
#define	ddrServo8	DDRF

#define	bnServo1	0
#define	bnServo2	1
#define	bnServo3	2
#define	bnServo4	3
#define	bnServo5	4
#define	bnServo6	5
#define	bnServo7	6
#define	bnServo8	7

/* ------------------------------------------------------------ */

#endif

/************************************************************************/
