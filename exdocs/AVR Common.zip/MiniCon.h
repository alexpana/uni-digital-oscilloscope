/************************************************************************/
/*																		*/
/*	MiniCon.h	--	Declarations for MiniCon Devices					*/
/*																		*/
/************************************************************************/
/*	Author:		Gene Apperson											*/
/*	Copyright 2005, Digilent Inc.										*/
/************************************************************************/
/*  File Description:													*/
/*																		*/
/*	Declarations for symbols defining on-board MiniCon devices and		*
/*	connectors.															*/
/*																		*/
/*	The declarations in this header assume that the WinAVR standard		*/
/*	i/o file has been included. (avr/io.h)								*/
/*																		*/
/*	The following naming conventions are used:							*/
/*		prtXXXX		- output port register number (PORTA, PORTB, etc)	*/
/*		pinXXXX		- input pin register number (PINA, PINB, etc)		*/
/*		ddrXXXX		- data direction register (DDRA, DDRB, etc)			*/
/*		bnXXX		- bit number within a register						*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	10/18/2005(GeneA): created											*/
/*																		*/
/************************************************************************/

#if !defined(_MINICON_INC)
#define	_MINICON_INC

/* ------------------------------------------------------------ */
/*				Declarations for On-Board LEDs					*/
/* ------------------------------------------------------------ */
/* NOTE: The on-board LEDs are shared with the pins on interface
**	connector JA. To drive the LEDs, the appropriate PORTD bits
**	are set as outputs. A logic 1 on the output pin turns the LED
**	on, a 0 turns it off. The LEDs consume about 1.9ma of current,
**	which should not interfere with most uses of these pins to
**	drive logic connected to JA.
*/

#define	prtLed0	PORTD		// output port for LED0
#define	prtLed1	PORTD		// output port for LED1
#define	prtLed2	PORTD		// output port for LED2
#define	prtLed3	PORTD		// output port for LED3

#define	ddrLed0	DDRD
#define	ddrLed1	DDRD
#define	ddrLed2	DDRD
#define	ddrLed3	DDRD

#define	bnLed0	4
#define	bnLed1	5
#define	bnLed2	6
#define	bnLed3	7

/* Mode select jumpers.
** JP5 and JP6 are connected to digital inputs.
*/
#define	prtJP5	PORTB
#define	prtJP6	PORTB

#define	pinJP5	PINB
#define	pinJP6	PINB

#define	ddrJP5	DDRB
#define	ddrJP6	DDRB

#define	bnJP5	6
#define	bnJP6	7

/* Jumpers JP7 and JP8 are connected via a resistor divider
** network to analog input ADC6. The following voltages will be
** present at the ADC6 input:
**		No jumper		VCC 	(3.3V)
**		JP7 loaded		2*VCC/3	(2.2V)
**		JP8 loaded		VCC/3	(1.1V)
**		both loaded		2*VCC/3	(2.2V)
*/

/* The ADC7 input can be used to monitor the unregulated power
** supply voltage. For battery powered operation, this can be
** used to monitor the battery voltage. This pin is connected
** to a voltage divider that divides VU by 4.
*/

/* ------------------------------------------------------------ */
/*			Declarations for Interface Connector Pins			*/
/* ------------------------------------------------------------ */

/* The following symbols define the interface for connector JA
*/
#define	prtJA1	PORTD
#define	prtJA2	PORTD
#define	prtJA3	PORTD
#define	prtJA4	PORTD

#define pinJA1	PIND
#define	pinJA2	PIND
#define pinJA3	PIND
#define pinJA4	PIND

#define	ddrJA1	DDRD
#define	ddrJA2	DDRD
#define	ddrJA3	DDRD
#define	ddrJA4	DDRD

#define	bnJA1	4
#define	bnJA2	5
#define	bnJA3	6
#define	bnJA4	7

/* The following symbols define the interface for connector JB
*/
#define	prtJB1	PORTD
#define	prtJB2	PORTB
#define	prtJB3	PORTB
#define	prtJB4	PORTD

#define	pinJB1	PIND
#define	pinJB2	PINB
#define	pinJB3	PINB
#define	pinJB4	PIND

#define	ddrJB1	DDRD
#define	ddrJB2	DDRB
#define	ddrJB3	DDRB
#define	ddrJB4	DDRD

#define	bnJB1	2
#define	bnJB2	1
#define	bnJB3	0
#define	bnJB4	3

/* The following symbols define the interface for connector JC
*/
#define	prtJC1	PORTC
#define	prtJC2	PORTC
#define	prtJC3	PORTC
#define	prtJC4	PORTC

#define	pinJC1	PINC
#define	pinJC2	PINC
#define	pinJC3	PINC
#define	pinJC4	PINC

#define	ddrJC1	DDRC
#define	ddrJC2	DDRC
#define	ddrJC3	DDRC
#define	ddrJC4	DDRC

#define	bnJC1	0
#define	bnJC2	1
#define	bnJC3	2
#define	bnJC4	3

/* The following symbols define the interface to the SPI connector
*/
/* SPI connector as SPI interface
*/
#define	prtSpi	PORTB
#define	pinSpi	PINB
#define	ddrSpi	DDRB

#define	bnSpiSS		2
#define	bnSpiMosi	3
#define	bnSpiMiso	4
#define	bnSpiSck	5

/* SPI connector as generic digital I/Os
*/
#define	prtSpi1	PORTB
#define	prtSpi2	PORTB
#define	prtSpi3	PORTB
#define	prtSpi4	PORTB

#define	pinSpi1	PINB
#define	pinSpi2	PINB
#define	pinSpi3	PINB
#define	pinSpi4	PINB

#define	ddrSpi1	DDRB
#define	ddrSpi2	DDRB
#define	ddrSpi3	DDRB
#define	ddrSpi4	DDRB

#define	bnSpi1	2
#define	bnSpi2	3
#define	bnSpi3	4
#define	bnSpi4	5

/* The following symbols define the interface to the TWI/UART connector
*/
/* TWI and UART interfaces
*/
#define	prtTwi	PORTC
#define	pinTwi	PINC
#define	ddrTwi	DDRC

#define	bnTwiScl	5
#define	bnTwiSda	4

#define	prtUart	PORTD
#define	pinUart	PIND
#define	ddrUart	DDRD

#define	bnUartRxd	0
#define	bnUartTxd	1

/* TWI/UART connecter as generic digital I/Os
*/
#define	prtTwi1	PORTC
#define	prtTwi2	PORTC
#define	prtTwi3	PORTD
#define	prtTwi4	PORTD

#define	pinTwi1	PINC
#define	pinTwi2	PINC
#define pinTwi3	PIND
#define	pinTwi4	PIND

#define	ddrTwi1	DDRC
#define	ddrTwi2	DDRC
#define	ddrTwi3	DDRD
#define	ddrTwi4	DDRD

#define	bnTwi1	5
#define	bnTwi2	4
#define	bnTwi3	0
#define	bnTwi4	1

/* ------------------------------------------------------------ */

#endif

/************************************************************************/
