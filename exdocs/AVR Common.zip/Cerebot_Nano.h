/************************************************************************/
/*																		*/
/*	Cerebot Nano.h	--	Declarations for Cerebot Nano Board				*/
/*																		*/
/************************************************************************/
/*	Author:		Gene Apperson											*/
/*	Copyright 2009, Digilent Inc.										*/
/************************************************************************/
/*  File Description:													*/
/*																		*/
/*	Declarations for symbols defining on-board Cerebot Nano devices.	*/
/*																		*/
/*	The declarations in this header assume that the WinAVR standard		*/
/*	i/o file has been included. (avr/io.h)								*/
/*																		*/
/*	The following naming conventions are used:							*/
/*		prtXXXX		- output port register number (PORTA, PORTB, etc)	*/
/*		pinXXXX		- input pin register number (PINA, PINB, etc)		*/
/*		ddrXXXX		- data direction register (DDRA, DDRB, etc)			*/
/*		bnXXX		- bit number within a register						*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	04/25/2009(GeneA): created											*/
/*																		*/
/************************************************************************/

#if !defined(_CEREBOT_NANO_INC)
#define	_CEREBOT_NANO_INC

/* ------------------------------------------------------------ */
/*				Declarations for On-Board LEDs					*/
/* ------------------------------------------------------------ */
/* NOTE: The on-board LEDs are shared with the pins on interface
** connectors JA and JB. To drive the LEDs, the appropriate PORTD bits
** are set as outputs. A 1 on the output port pin turns the LED
** on, a 0 turns it off. The LEDs consume about 1.9ma of current,
** which should not interfere with most uses of these pins to
** drive logic connected to JA or JB.
*/

#define	prtLed0	PORTD		// output port for LED0
#define	prtLed1	PORTD		// output port for LED1
#define	prtLed2	PORTD		// output port for LED2
#define	prtLed3	PORTD		// output port for LED3

#define	ddrLed0	DDRD
#define	ddrLed1	DDRD
#define	ddrLed2	DDRD
#define	ddrLed3	DDRD

#define	bnLed0	5
#define	bnLed1	3
#define	bnLed2	4
#define	bnLed3	2

/* The Cerebot Nano contains software selectable pull-up resistors
** on the TWI signal lines. Set these pins as outputs and drive
** them high to enable the pull-ups. Set the pins as inputs with
** internal pull-ups disabled to disable the TWI pull-ups. The TWI
** bus is an open collector bus. Some device on the bus must provide
** pull-up resistors. Generally only one device on the bus should
** have pull-ups.
*/
#define	prtTwiPen	= PORTB
#define	ddrTwiPen	= DDRB

#define	bnTwiPeScl	= 6
#define	bnTwiPeSda	= 7

/* ------------------------------------------------------------ */
/*			Declarations for Interface Connector Pins			*/
/* ------------------------------------------------------------ */

/* The following symbols define the interface for connector JA
*/
#define	prtJA1	PORTC
#define	prtJA2	PORTC
#define	prtJA3	PORTC
#define	prtJA4	PORTC
#define	prtJA7	PORTD
#define	prtJA8	PORTB
#define	prtJA9	PORTD
#define	prtJA10	PORTB

#define pinJA1	PINC
#define	pinJA2	PINC
#define pinJA3	PINC
#define pinJA4	PINC
#define pinJA7	PIND
#define	pinJA8	PINB
#define pinJA9	PIND
#define pinJA10	PINB

#define	ddrJA1	DDRC
#define	ddrJA2	DDRC
#define	ddrJA3	DDRC
#define	ddrJA4	DDRC
#define	ddrJA7	DDRD
#define	ddrJA8	DDRB
#define	ddrJA9	DDRD
#define	ddrJA10	DDRB

#define	bnJA1	0
#define	bnJA2	1
#define	bnJA3	2
#define	bnJA4	3
#define	bnJA1	2
#define	bnJA2	1
#define	bnJA3	0
#define	bnJA4	3

/* The following symbols define the interface for connector JB
*/
#define	prtJB1	PORTC
#define	prtJB2	PORTC
#define	prtJB3	PORTD
#define	prtJB4	PORTD
#define	prtJB7	PORTD
#define	prtJB8	PORTD
#define	prtJB9	PORTD
#define	prtJB10	PORTD

#define pinJB1	PINC
#define	pinJB2	PINC
#define pinJB3	PIND
#define pinJB4	PIND
#define pinJB7	PIND
#define	pinJB8	PIND
#define pinJB9	PIND
#define pinJB10	PIND

#define	ddrJB1	DDRC
#define	ddrJB2	DDRC
#define	ddrJB3	DDRD
#define	ddrJB4	DDRD
#define	ddrJB7	DDRD
#define	ddrJB8	DDRD
#define	ddrJB9	DDRD
#define	ddrJB10	DDRD

#define	bnJB1	5
#define	bnJB2	4
#define	bnJB3	0
#define	bnJB4	1
#define	bnJB1	4
#define	bnJB2	5
#define	bnJB3	6
#define	bnJB4	7

/* The following symbols are used for the SPI (J1).
** Connector J1 provides access to the SPI controller. It is also
** useable for general purpose I/O. Note: If the SS/RST jumper JP1
** is in the RST position, pin1 (PORTB bit 2) is not available as an
** I/O pin.
*/

/* Connector J1 as SPI interface
*/
#define	prtSpi	PORTB
#define pinSpi	PINB
#define	ddrSpi	DDRB

#define	bnSpiSS		2
#define	bnSpiMosi	3
#define	bnSpiMiso	4
#define	bnSpiSck	5

/* Connector J1 as general digital i/o
*/
#define	prtSpi1	PORTB
#define	prtSpi2	PORTB
#define	prtSpi3	PORTB
#define	prtSpi4	PORTB

#define	pinSpi1	PINB
#define	pinSpi2	PINB
#define	pinSpi3	PINB
#define	pinSpi4	PINB

#define	ddrSpi1	DDRB
#define	ddrSpi2	DDRB
#define	ddrSpi3	DDRB
#define ddrSpi4	DDRB

#define	bnSpi1	2
#define	bnSpi2	3
#define	bnSpi3	4
#define	bnSpi4	5

/* ------------------------------------------------------------ */

#endif

/************************************************************************/
