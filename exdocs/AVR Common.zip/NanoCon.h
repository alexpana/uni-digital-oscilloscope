/************************************************************************/
/*																		*/
/*	NanoCon.h	--	Declarations for NanoCon Devices					*/
/*																		*/
/************************************************************************/
/*	Author:		Gene Apperson											*/
/*	Copyright 2005, 2006, Digilent Inc.									*/
/************************************************************************/
/*  File Description:													*/
/*																		*/
/*	Declarations for symbols defining on-board NanoCon devices and		*
/*	connectors.															*/
/*																		*/
/*	The declarations in this header assume that the WinAVR standard		*/
/*	i/o file has been included. (avr/io.h)								*/
/*																		*/
/*	The following naming conventions are used:							*/
/*		prtXXXX		- output port register number (PORTA, PORTB, etc)	*/
/*		pinXXXX		- input pin register number (PINA, PINB, etc)		*/
/*		ddrXXXX		- data direction register (DDRA, DDRB, etc)			*/
/*		bnXXX		- bit number within a register						*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	10/18/2005(GeneA): created											*/
/*	03/30/2006(GeneA): updated for Rev B board							*/
/*																		*/
/************************************************************************/

#if !defined(_NANOCON_INC)
#define	_NANOCON_INC

/* ------------------------------------------------------------ */
/*				Declarations for On-Board LEDs					*/
/* ------------------------------------------------------------ */
/* NOTE: To drive the LEDs, the appropriate DDR bits are set as outputs.
**  A logic 1 on the output pin turns the LED on, a 0 turns it off.
*/

#define	prtLed0	PORTD		// output port for LED0
#define	prtLed1	PORTD		// output port for LED1
#define	prtLed2	PORTD		// output port for LED2
#define	prtLed3	PORTD		// output port for LED3

#define	ddrLed0	DDRD
#define	ddrLed1	DDRD
#define	ddrLed2	DDRD
#define	ddrLed3	DDRD

#define	bnLed0	4
#define	bnLed1	5
#define	bnLed2	6
#define	bnLed3	7

/* TWI pullups. The NanoCon is set up with software selectable
** pull-up resistors on the TWI signal lines. Set the pins as
** outputs and drive them high to enable the pullups. Set the pins
** as inputs, with internal pull-ups disabled, to disable the
** pull-ups. TWI is an open collector bus. One and only one device
** on the bus should provide the pull-ups.
*/
#define	prtTwiPen	PORTB

#define	ddrTwiPen	DDRB

#define	bnTwiPeScl	6
#define	bnTwiPeSda	7

/* ------------------------------------------------------------ */
/*			Declarations for Interface Connector Pins			*/
/* ------------------------------------------------------------ */

/* The following symbols define the interface for connector JA
*/
#define	prtJA1	PORTC
#define	prtJA2	PORTC
#define	prtJA3	PORTD
#define	prtJA4	PORTD

#define pinJA1	PINC
#define	pinJA2	PINC
#define pinJA3	PIND
#define pinJA4	PIND

#define	ddrJA1	DDRC
#define	ddrJA2	DDRC
#define	ddrJA3	DDRD
#define	ddrJA4	DDRD

#define	bnJA1	5
#define	bnJA2	4
#define	bnJA3	0
#define	bnJA4	1

/* The following symbols define the interface for connector JB
*/
#define	prtJB1	PORTC
#define	prtJB2	PORTC
#define	prtJB3	PORTC
#define	prtJB4	PORTC

#define	pinJB1	PINC
#define	pinJB2	PINC
#define	pinJB3	PINC
#define	pinJB4	PINC

#define	ddrJB1	DDRC
#define	ddrJB2	DDRC
#define	ddrJB3	DDRC
#define	ddrJB4	DDRC

#define	bnJB1	0
#define	bnJB2	1
#define	bnJB3	2
#define	bnJB4	3

/* The following symbols define the interface for connector JC
*/
#define	prtJC1	PORTD
#define	prtJC2	PORTB
#define	prtJC3	PORTB
#define	prtJC4	PORTD

#define	pinJC1	PIND
#define	pinJC2	PINB
#define	pinJC3	PINB
#define	pinJC4	PIND

#define	ddrJC1	DDRD
#define	ddrJC2	DDRB
#define	ddrJC3	DDRB
#define	ddrJC4	DDRD

#define	bnJC1	2
#define	bnJC2	1
#define	bnJC3	0
#define	bnJC4	3

/* The following symbols define the interface to the SPI connector, J1
*/
/* J1 connector as SPI interface
*/
#define	prtSpi	PORTB
#define	pinSpi	PINB
#define	ddrSpi	DDRB

#define	bnSpiSS		2
#define	bnSpiMosi	3
#define	bnSpiMiso	4
#define	bnSpiSck	5

/* J1 connector as generic digital I/Os
*/
#define	prtSpi1	PORTB
#define	prtSpi2	PORTB
#define	prtSpi3	PORTB
#define	prtSpi4	PORTB

#define	pinSpi1	PINB
#define	pinSpi2	PINB
#define	pinSpi3	PINB
#define	pinSpi4	PINB

#define	ddrSpi1	DDRB
#define	ddrSpi2	DDRB
#define	ddrSpi3	DDRB
#define	ddrSpi4	DDRB

#define	bnSpi1	2
#define	bnSpi2	3
#define	bnSpi3	4
#define	bnSpi4	5

/* The following symbols define the interface to the TWI/UART connector.
** This connector is also JA. The pins are defined as generic I/Os in
** the JA declarations.
*/
/* TWI and UART interfaces
*/
#define	prtTwi	PORTC
#define	pinTwi	PINC
#define	ddrTwi	DDRC

#define	bnTwiScl	5
#define	bnTwiSda	4

#define	prtUart	PORTD
#define	pinUart	PIND
#define	ddrUart	DDRD

#define	bnUartRxd	0
#define	bnUartTxd	1

/* ------------------------------------------------------------ */

#endif

/************************************************************************/
