/************************************************************************/
/*																		*/
/*	main.c	--	Primary program file for project						*/
/*																		*/
/************************************************************************/
/*	Author: 	Mark Taylor												*/
/*	Copyright 2007, Digilent Inc.										*/
/************************************************************************/
/*  Module Description: 												*/
/*																		*/
/*	This project gives a brief introduction to the Digilent Cerebot II.	*/
/*	This illustrates how to set up and read inputs and how to use the 	*/
/*	onboard LEDs as output.												*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	07/03/2007(MarkT): created											*/
/*																		*/
/************************************************************************/

/* ------------------------------------------------------------ */
/*				Include File Definitions						*/
/* ------------------------------------------------------------ */

#include <avr/io.h>
#include <avr/interrupt.h>

#include	"stdtypes.h"
#include	"cerebotII.h"
#include	"main.h"

/* ------------------------------------------------------------ */
/*				Local Type Definitions							*/
/* ------------------------------------------------------------ */


/* ------------------------------------------------------------ */
/*				Global Variables								*/
/* ------------------------------------------------------------ */


/* ------------------------------------------------------------ */
/*				Local Variables									*/
/* ------------------------------------------------------------ */


/* ------------------------------------------------------------ */
/*				Forward Declarations							*/
/* ------------------------------------------------------------ */


/* ------------------------------------------------------------ */
/*				Interrupt Service Routines						*/
/* ------------------------------------------------------------ */


/* ------------------------------------------------------------ */
/*				Procedure Definitions							*/
/* ------------------------------------------------------------ */
/***	main
**
**	Synopsis:
**		st = main()
**
**	Parameters:
**		none
**
**	Return Values:
**		does not return
**
**	Errors:
**		none
**
**	Description:
**		Main program module. Performs basic board initialization
**		and then enters the main program loop.
**
*/

int
main(void)
{
	DeviceInit();
	AppInit();

	while (fTrue){

		//if JP5 is in the '1' position, display a binary counter
		if(pinJP5 & (1 << bnJP5)){
			PORTE += 16;
			Wait_ms(200);
		}

		else{  //display a scrolling LED
			if(prtLed1 & (1 << bnLed1)){
				prtLed1 &= ~(1 << bnLed1);
				prtLed2 |= (1 << bnLed2);
				prtLed3 &= ~(1 << bnLed3);
				prtLed4 &= ~(1 << bnLed4);
			}
			else if(prtLed2 & (1 << bnLed2)){
				prtLed1 &= ~(1 << bnLed1);
				prtLed2 &= ~(1 << bnLed2);
				prtLed3 |= (1 << bnLed3);
				prtLed4 &= ~(1 << bnLed4);
			}
			else if(prtLed3 & (1 << bnLed3)){
				prtLed1 &= ~(1 << bnLed1);
				prtLed2 &= ~(1 << bnLed2);
				prtLed3 &= ~(1 << bnLed3);
				prtLed4 |= (1 << bnLed4);
			}
			else if(prtLed4 & (1 << bnLed4)){
				prtLed1 |= (1 << bnLed1);
				prtLed2 &= ~(1 << bnLed2);
				prtLed3 &= ~(1 << bnLed3);
				prtLed4 &= ~(1 << bnLed4);
			}
			else{
				prtLed1 |= (1 << bnLed1);
			}

			Wait_ms(100);
		}

	}  //end while

}  //end main

/* ------------------------------------------------------------ */
/***	DeviceInit
**
**	Synopsis:
**		DeviceInit()
**
**	Parameters:
**		none
**
**	Return Values:
**		none
**
**	Errors:
**		none
**
**	Description:
**		Initializes on chip peripheral devices to the default
**		state.
*/

void
DeviceInit()
{
	/* Default all i/o ports to input with pull-ups enabled
	*/
	DDRA = 0;
	DDRB = 0;
	DDRC = 0;
	DDRD = 0;
	DDRE = 0;
	DDRF = 0;

	PORTA = 0xFF;
	PORTB = 0xFF;
	PORTC = 0xFF;
	PORTD = 0xFF;
	PORTE = 0xFF;
	PORTF = 0xFF;

	/*The above statements sets all ports as inputs (DDRx = 0) and enables the internal
	  pull-up resistors on those pins (PORTx = 0xFF).  This includes the data direction
	  register and pull-up that handles the User Input Jumper JP5. */
	  	
	//Set the data direction register of the LEDs as output
	ddrLed1 |= (1 << bnLed1);
	ddrLed2 |= (1 << bnLed2);
	ddrLed3 |= (1 << bnLed3);
	ddrLed4 |= (1 << bnLed4);

	//Set the LEDs pins low (off) initially
	prtLed1 &= ~(1 << bnLed1);
	prtLed2 &= ~(1 << bnLed2);
	prtLed3 &= ~(1 << bnLed3);
	prtLed4 &= ~(1 << bnLed4);
}

/* ------------------------------------------------------------ */
/***	AppInit
**
**	Synopsis:
**		AppInit()
**
**	Parameters:
**		none
**
**	Return Values:
**		none
**
**	Errors:
**		none
**
**	Description:
**		Performs application specific initialization. Sets devices
**		and global variables for application.
*/

void
AppInit()
{
	/* Initialization of global variables, such as flags, would go in this 
	  function */

	sei();  //enable global interrupts.
}

/* ------------------------------------------------------------ */
/***	Wait_ms
**
**	Synopsis:
**		Wait_ms(WORD)
**
**	Parameters:
**		WORD (range from 0 to 65535)
**
**	Return Values:
**		none
**
**	Errors:
**		none
**
**	Description:
**		Will wait for specified number of milliseconds.  Using a 
**		word variable allows for delays up to 65.535 seconds.  The value
**		in the for statement may need to be altered depending on how your
**		compiler translates this code into AVR assembly.  In assembly, it is
**		possible to generate exact delay values by counting the number of clock
**		cycles your loop takes to execute.  When writing code in C, the compiler
**		interprets the code, and translates it into assembly.  This process is 
**		notoriously inefficient and may vary between different versions of AVR Studio
**		and WinAVR GCC.  A handy method of calibrating the delay loop is to write a 
**		short program that toggles an LED on and off once per second using this 
**		function and using a watch to time how long it is actually taking to
**		complete. 
**
*/

void Wait_ms(WORD delay)
{
	WORD i;

	while(delay > 0){

		for( i = 0; i < 390; i ++){
			;;
		}
		delay -= 1;
	}
}










